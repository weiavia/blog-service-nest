import { CustomException } from "@app/exceptions/base.exception";

export class ParamException extends CustomException {
  constructor(customDto?) {
    super(customDto, {
      message: 'child message'
    })
  }
}