interface returnParam {
  errno?:number
  status?: number
  message?: string
}

export class CustomException {
  errno:number = 0
  status:number = 200
  message:string = 'custom exception'
  customDto:returnParam
  childDot:returnParam
  
  /* 
    自定义异常返回前端的数据模板
    优先级：customDto > childDot > CustomException默认参数
  */
  constructor(customDto?: returnParam, childDot?: returnParam) {
    this.customDto = customDto
    this.childDot = childDot
    this.useDto()
  }

  useDto () {
    if(this.childDot && !this.customDto) {
      this.errno = this.childDot.errno || this.errno
      this.status = this.childDot.status || this.status
      this.message = this.childDot.message || this.message
    } else {
      this.errno = this.customDto.errno || this.errno
      this.status = this.customDto.status || this.status
      this.message = this.customDto.message || this.message
    }
  }
}