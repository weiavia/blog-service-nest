import { Module, NestModule, MiddlewareConsumer } from '@nestjs/common';
import { AppController } from '@app/modules/app.controller';
import { AppService } from '@app/modules/app.service';
import { UserService } from '@app/modules/user/user.service';
import { UserModule } from '@app/modules/user/user.module';
import { BookModule } from '@app/modules/book/book.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserController } from '@app/modules/user/user.controller';
import { AuthModule } from './auth/auth.module';
import { AuthMiddleware } from '@app/middleware/auth.middleware';
import { AuthService } from '@app/modules/auth/auth.service';

const imports = [
  AuthModule, 
  UserModule, 
  BookModule, 
  TypeOrmModule.forRoot()
]

const controllers = [
  AppController,
  UserController
]

const providers = [
  AppService,
  UserService,
  AuthService
]

@Module({
  imports,
  controllers,
  providers
})

export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(AuthMiddleware)
            .forRoutes('/')
  }
}