import { Injectable } from '@nestjs/common';

@Injectable()
export class BookService {
  constructor () {}
  
  getBook() {
    return '逍遥叹'
  }
}
