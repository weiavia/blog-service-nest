import { Controller, Get, Body, BadGatewayException, UseInterceptors } from '@nestjs/common';
import { AppService } from '@app/modules/app.service';
import { ParamException } from '@app/exceptions/param.exception';
import { BackInterceptor } from '@app/helpers/back.interceptor';

@Controller()
@UseInterceptors(new BackInterceptor())
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  app(@Body('name') param): any {

  }
}